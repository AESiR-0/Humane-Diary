# Humane-Diary
A diary which classifies the audio log according to their emotions on a scale of a good day to bad day
